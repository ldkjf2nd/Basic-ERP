package beans;

public class Item {
	
	private int itemId;
	private String partId;
	private String partName;
	private String Description;
	private String revision;
	private int customerId;
	
	
	
	public int getItemId() {
		return itemId;
	}
	
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}



	public String getPartId() {
		return partId;
	}



	public void setPartId(String partId) {
		this.partId = partId;
	}



	public String getPartName() {
		return partName;
	}



	public void setPartName(String partName) {
		this.partName = partName;
	}



	public String getDescription() {
		return Description;
	}



	public void setDescription(String description) {
		Description = description;
	}



	public String getRevision() {
		return revision;
	}



	public void setRevision(String revision) {
		this.revision = revision;
	}



	public int getCustomerId() {
		return customerId;
	}



	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	
	
}
