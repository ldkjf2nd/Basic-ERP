package module;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import beans.salesOrder;
import db.ConnectionManager;
import db.InputManager;

public class salesOrderManager {
	private static Connection conn = ConnectionManager.getInstance().getConnection();
	
	public static void displayAllRows() throws SQLException {
		String sql = "SELECT soId, itemId, customerId, quantity, dueDate, shipDate, close FROM salesOrder";
		try (

				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql);
				){

			System.out.println("workOrder:");
			while (rs.next()) {
				StringBuffer bf = new StringBuffer();
				bf.append(rs.getInt("soId") + ": ");
				bf.append(rs.getInt("itemId") +", ");
				bf.append(rs.getString("customerId") +", ");
				bf.append(rs.getInt("quantity") +", ");
				bf.append(rs.getString("dueDate") +", ");
				bf.append(rs.getString("shipDate")+", ");
				bf.append(rs.getBoolean("close"));
				System.out.println(bf.toString());
			}
		}
	}
	
	public static salesOrder getRow(int soId) throws SQLException {

		String sql = "SELECT * FROM salesOrder WHERE soId = ?";
		ResultSet rs = null;

		try (
				PreparedStatement stmt = conn.prepareStatement(sql);
				){
			stmt.setInt(1, soId);
			rs = stmt.executeQuery();

			if (rs.next()) {
				salesOrder bean = new salesOrder();
				bean.setSoId(soId);
				bean.setItemId(rs.getInt("itemId"));
				bean.setCustomerId(rs.getString("customerId"));
				bean.setQuantity(rs.getInt("quantity"));
				bean.setDueDate(rs.getString("dueDate"));
				bean.setShipDate(rs.getString("shipDate"));
				bean.setClose(rs.getBoolean("close"));
				return bean;
			} else {
				return null;
			}

		} catch (SQLException e) {
			System.err.println(e);
			return null;
		} finally {
			if (rs != null) {
				rs.close();
			}
		}

	}
	
	public static boolean insert(salesOrder bean) throws Exception {

		String sql = "INSERT into salesOrder (itemId, customerId, quantity, dueDate, shipDate) " +
				"VALUES (?, ?, ?, ?, ?)";
		ResultSet keys = null;
		try (
				PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				) {
			
			stmt.setInt(1, bean.getItemId());
			stmt.setString(2, bean.getCustomerId());
			stmt.setInt(3, bean.getQuantity());
			stmt.setString(4, bean.getDueDate());
			stmt.setString(5, bean.getShipDate());
			int affected = stmt.executeUpdate();
			
			if (affected == 1) {
				keys = stmt.getGeneratedKeys();
				keys.next();
				int newKey = keys.getInt(1);
				bean.setSoId(newKey);
			} else {
				System.err.println("No rows affected");
				return false;
			}
			
		} catch (SQLException e) {
			System.err.println(e);
			return false;
		} finally{
			if (keys != null) keys.close();
		}
		return true;
	}
	
	public static boolean update(salesOrder bean) throws Exception {

		String sql =
				"UPDATE salesOrder SET " +
				"itemId = ?, customerId = ?, quantity = ?, dueDate = ?, shipDate = ?" +
				"WHERE soId = ?";
		try (
				PreparedStatement stmt = conn.prepareStatement(sql);
				){
			
			stmt.setInt(1, bean.getItemId());
			stmt.setString(2, bean.getCustomerId());
			stmt.setInt(3, bean.getQuantity());
			stmt.setString(4, bean.getDueDate());
			stmt.setString(5, bean.getShipDate());
			stmt.setInt(6, bean.getSoId());
			
			int affected = stmt.executeUpdate();
			if (affected == 1) {
				return true;
			} else {
				return false;
			}
			
		}
		catch(SQLException e) {
			System.err.println(e);
			return false;
		}

	}
	
	public static boolean ship(salesOrder bean) throws Exception {

		String sql =
				"UPDATE salesOrder SET " +
				"shipDate = ? " +
				"WHERE soId = ?";
		try (
				PreparedStatement stmt = conn.prepareStatement(sql);
				){
			
			stmt.setString(1, bean.getShipDate());
			stmt.setInt(2, bean.getSoId());
			
			int affected = stmt.executeUpdate();
			if (affected == 1) {
				return true;
			} else {
				return false;
			}
			
		}
		catch(SQLException e) {
			System.err.println(e);
			return false;
		}

	}
	
	public static boolean close(salesOrder bean) throws Exception {

		String sql =
				"UPDATE salesOrder SET " +
				"close = NOT close " +
				"WHERE soId = ?";
		try (
				PreparedStatement stmt = conn.prepareStatement(sql);
				){
			
			stmt.setInt(1, bean.getSoId());
			
			int affected = stmt.executeUpdate();
			if (affected == 1) {
				return true;
			} else {
				return false;
			}
			
		}
		catch(SQLException e) {
			System.err.println(e);
			return false;
		}

	}
	
	public static void main(String[] args) throws Exception {
		
		System.out.println("Starting application");
		
		ConnectionManager.getInstance();
		
		displayAllRows();
		
		System.out.println("Functions: 1. Search Sales Order, 2. Create new Sales Order, 3. Update Sales Order, 4. Ship Sales Order, 5. Close Sales Order, 0. Exit");
		int fun = InputManager.getIntegerInput("Enter corresponding integer: ");
		switch (fun) {
		case 1:
			int id = InputManager.getIntegerInput("Enter the item number for search: ");
			salesOrder srch = getRow(id);
			if (srch != null) {
				System.out.println("Item ID: " + srch.getItemId());
				System.out.println("Customer ID: " + srch.getCustomerId());
				System.out.println("Quantity: " + srch.getQuantity());
				System.out.println("Due Date: " + srch.getDueDate());
				System.out.println("Ship Date: " + srch.getShipDate());
				System.out.println("Closure: " + srch.isClose());
			} else {
				System.out.println("Sales Order not found.");
			}
			break;

		case 2:
			salesOrder create = new salesOrder();
			create.setItemId(InputManager.getIntegerInput("Insert Item ID of Sales Order: "));
			create.setQuantity(InputManager.getIntegerInput("Insert quantity of Item in Sales Order: "));
			create.setCustomerId(InputManager.getInput("Insert ID of Customer for Sales Order: "));
			create.setDueDate(InputManager.getInput("Insert due date of Sales Order: "));
			create.setShipDate(InputManager.getInput("Insert ship date of Sales Order: "));
			
			if (insert(create)) {
				System.out.println("Operation successful.");
			} else {
				System.out.println("Operation unsuccessful.");
			}
			break;
			
		case 3:
			salesOrder upd = getRow(InputManager.getIntegerInput("Enter Sales Order ID to update: "));
			upd.setItemId(InputManager.getIntegerInput("Update Item ID: "));
			upd.setCustomerId(InputManager.getInput("Update customer ID: "));
			upd.setQuantity(InputManager.getIntegerInput("Update quantity: "));
			upd.setDueDate(InputManager.getInput("Update due date: "));
			upd.setShipDate(InputManager.getInput("Update ship date: "));
			
			if(update(upd)) {
				System.out.println("Update successful.");
			} else {
				System.out.println("Update unsuccessful.");
			}
			break;
			
		case 4:
			salesOrder shp = new salesOrder();
			shp.setSoId(InputManager.getIntegerInput("Enter Sales Order ID to ship: "));
			String date = java.time.LocalDate.now().toString();
			shp.setShipDate(date);
			
			if(ship(shp)) {
				System.out.println("Update successful.");
			} else {
				System.out.println("Update unsuccessful.");
			}
			break;
			
		case 5:
			salesOrder cls = new salesOrder();
			cls.setSoId(InputManager.getIntegerInput("Enter Sales Order ID to close: "));
			
			if(close(cls)) {
				System.out.println("Update successful.");
			} else {
				System.out.println("Update unsuccessful.");
			}
			break;
			
		case 0:
			break;
			
		default:
			break;
		}
		ConnectionManager.getInstance().close();
	}
}
