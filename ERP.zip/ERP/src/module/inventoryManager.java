package module;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import beans.inventory;
import db.ConnectionManager;
import db.InputManager;

public class inventoryManager {
	
	private static Connection conn = ConnectionManager.getInstance().getConnection();

	public static void displayAllRows() throws SQLException {
		String sql = "SELECT inventoryId, itemId, quantity, lotId, batchId, manufacturerCode, comment FROM inventory";
		try (

				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql);
				){

			System.out.println("Inventory:");
			while (rs.next()) {
				StringBuffer bf = new StringBuffer();
				bf.append(rs.getInt("inventoryId") + ": ");
				bf.append(rs.getString("itemId") +", ");
				bf.append(rs.getString("quantity") +", ");
				bf.append(rs.getString("lotId") +", ");
				bf.append(rs.getString("batchId") +", ");
				bf.append(rs.getString("manufacturerCode"));
				bf.append(rs.getString("comment"));
				System.out.println(bf.toString());
			}
		}
	}
	
	public static inventory getRow(int inventoryId) throws SQLException {

		String sql = "SELECT * FROM inventory WHERE inventoryId = ?";
		ResultSet rs = null;

		try (
				PreparedStatement stmt = conn.prepareStatement(sql);
				){
			stmt.setInt(1, inventoryId);
			rs = stmt.executeQuery();

			if (rs.next()) {
				inventory bean = new inventory();
				bean.setItemId(rs.getInt("itemId"));
				bean.setQuantity(rs.getInt("quantity"));
				bean.setLotId(rs.getString("lotId"));
				bean.setBatchId(rs.getString("batchId"));
				bean.setManufacturerCode(rs.getString("manufacturerCode"));
				bean.setComment(rs.getString("comment"));
				return bean;
			} else {
				return null;
			}

		} catch (SQLException e) {
			System.err.println(e);
			return null;
		} finally {
			if (rs != null) {
				rs.close();
			}
		}

	}
	
	public static boolean insert(inventory bean) throws Exception {

		String sql = "INSERT into inventory (itemId, quantity, lotId, batchId, manufacturerCode, comment) " +
				"VALUES (?, ?, ?, ?, ?, ?)";
		ResultSet keys = null;
		try (
				PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				) {
			
			stmt.setInt(1, bean.getItemId());
			stmt.setInt(2, bean.getQuantity());
			stmt.setString(3, bean.getLotId());
			stmt.setString(4, bean.getBatchId());
			stmt.setString(5, bean.getManufacturerCode());
			stmt.setString(6, bean.getComment());
			int affected = stmt.executeUpdate();
			System.out.println(affected);
			
			if (affected == 1) {
				keys = stmt.getGeneratedKeys();
				keys.next();
				int newKey = keys.getInt(1);
				bean.setItemId(newKey);
			} else {
				System.err.println("No rows affected");
				return false;
			}
			
		} catch (SQLException e) {
			System.err.println(e);
			return false;
		} finally{
			if (keys != null) keys.close();
		}
		return true;
	}
	
	public static boolean update(inventory bean) throws Exception {

		String sql =
				"UPDATE inventory SET " +
				"itemId = ?, quantity = ?, lotId = ?, batchId = ?, manufacturerCode = ? , Comment = ?" +
				"WHERE inventoryId = ?";
		try (
				PreparedStatement stmt = conn.prepareStatement(sql);
				){
			
			stmt.setInt(1, bean.getItemId());
			stmt.setInt(2, bean.getQuantity());
			stmt.setString(3, bean.getLotId());
			stmt.setString(4, bean.getBatchId());
			stmt.setString(5, bean.getManufacturerCode());
			stmt.setString(6, bean.getComment());
			
			stmt.setInt(7, bean.getInventoryId());
			
			int affected = stmt.executeUpdate();
			if (affected == 1) {
				return true;
			} else {
				return false;
			}
			
		}
		catch(SQLException e) {
			System.err.println(e);
			return false;
		}

	}
	
	public static void main(String[] args) throws Exception {
		
		System.out.println("Starting application");
		
		ConnectionManager.getInstance();
		
		displayAllRows();
		
		System.out.println("Functions: 1. Get inventory record, 2. Insert inventory record, 3. Update Inventory record, 0. Exit");
		
		int fun = InputManager.getIntegerInput("Enter corresponding integer: ");
		
		switch (fun) {
		case 1:
			inventory row = getRow(InputManager.getIntegerInput("Enter record id: "));
			if (row != null) {
				System.out.println("Item ID: " + row.getItemId() + ", Quantity: " + row.getQuantity() + ", Lot number: " + row.getLotId() + 
						", Batch ID: " + row.getBatchId() + ", Manufacturer Code: " + row.getManufacturerCode() + ", Comment: " + row.getComment());
			}
			break;
		
		case 2:
			inventory insert = new inventory();
			insert.setItemId(InputManager.getIntegerInput("Insert item ID of inventory: "));
			insert.setQuantity(InputManager.getIntegerInput("Insert quantity of inventory: "));
			insert.setLotId(InputManager.getInput("Insert lot number of inventory: "));
			insert.setBatchId(InputManager.getInput("Insert batch number of inventory: "));
			insert.setManufacturerCode(InputManager.getInput("Insert Manufacturer code of inventory: "));
			insert.setComment(InputManager.getInput("Insert comment of inventory: "));
			
			if(insert(insert)) {
				System.out.println("Insert successful");
			}
			break;
		
		case 3:
			inventory upd = getRow(InputManager.getIntegerInput("Insert ID of inventory for update: "));
			if (upd != null) {
				upd.setItemId(InputManager.getIntegerInput("Update Item Id: "));
				upd.setQuantity(InputManager.getIntegerInput("Update Quantity: "));
				upd.setLotId(InputManager.getInput("Update Lot ID: "));
				upd.setBatchId(InputManager.getInput("Update Batch ID: "));
				upd.setManufacturerCode(InputManager.getInput("Update Manufacturer code: "));
				upd.setComment(InputManager.getInput("Update comment: "));
				
				boolean res = update(upd);	// currently update for inventory manager is not working properly
				if(res) {
					System.out.println("Update successful.");
				} else {
					System.out.println("Update unsuccessful.");
				}
			} else {
				System.out.println("Inventory record not found.");
			}
			
		case 0:
			break;

			
		default:
			System.out.println("Invalid input");
			break;
		}
		
		ConnectionManager.getInstance().close();	
	}
}
