package module;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import beans.workOrder;
import db.ConnectionManager;
import db.InputManager;

public class workOrderManager {

		private static Connection conn = ConnectionManager.getInstance().getConnection();
		
		public static void displayAllRows() throws SQLException {
			String sql = "SELECT woId, itemId, quantity, soId, complete, close FROM workOrder";
			try (

					Statement stmt = conn.createStatement();
					ResultSet rs = stmt.executeQuery(sql);
					){

				System.out.println("workOrder:");
				while (rs.next()) {
					StringBuffer bf = new StringBuffer();
					bf.append(rs.getInt("woId") + ": ");
					bf.append(rs.getInt("itemId") +", ");
					bf.append(rs.getInt("quantity") +", ");
					bf.append(rs.getInt("soId") +", ");
					bf.append(rs.getBoolean("complete") +", ");
					bf.append(rs.getBoolean("close"));
					System.out.println(bf.toString());
				}
			}
		}
		
		public static workOrder getRow(int woId) throws SQLException {

			String sql = "SELECT * FROM workOrder WHERE woId = ?";
			ResultSet rs = null;

			try (
					PreparedStatement stmt = conn.prepareStatement(sql);
					){
				stmt.setInt(1, woId);
				rs = stmt.executeQuery();

				if (rs.next()) {
					workOrder bean = new workOrder();
					bean.setWoId(woId);
					bean.setItemId(rs.getInt("itemId"));
					bean.setQuantity(rs.getInt("quantity"));
					bean.setSoId(rs.getInt("soId"));
					bean.setComplete(rs.getBoolean("complete"));
					bean.setClose(rs.getBoolean("close"));
					return bean;
				} else {
					return null;
				}

			} catch (SQLException e) {
				System.err.println(e);
				return null;
			} finally {
				if (rs != null) {
					rs.close();
				}
			}

		}
		
		public static boolean insert(workOrder bean) throws Exception {
			//insert new record
			String sql = "INSERT into workOrder (itemId, quantity, soId, complete, close) " +
					"VALUES (?, ?, ?, ?, ?)";
			ResultSet keys = null;
			try (
					PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
					) {
				
				stmt.setInt(1, bean.getItemId());
				stmt.setInt(2, bean.getQuantity());
				stmt.setInt(3, bean.getSoId());
				stmt.setBoolean(4, bean.isComplete());
				stmt.setBoolean(5, bean.isClose());
				int affected = stmt.executeUpdate();
				
				if (affected == 1) {
					keys = stmt.getGeneratedKeys();
					keys.next();
					int newKey = keys.getInt(1);
					bean.setWoId(newKey);
				} else {
					System.err.println("No rows affected");
					return false;
				}
				
			} catch (SQLException e) {
				System.err.println(e);
				return false;
			} finally{
				if (keys != null) keys.close();
			}
			return true;
		}
		
		public static boolean update(workOrder bean) throws Exception {
			
			//updating fields with new values
			String sql =
					"UPDATE workOrder SET " +
					"itemId = ?, quantity = ?, soId = ?, complete = ?, close = ? " +
					"WHERE woId = ?";
			try (
					PreparedStatement stmt = conn.prepareStatement(sql);
					){
				
				stmt.setInt(1, bean.getItemId());
				stmt.setInt(2, bean.getQuantity());
				stmt.setInt(3, bean.getSoId());
				stmt.setBoolean(4, bean.isComplete());
				stmt.setBoolean(5, bean.isClose());
				stmt.setInt(6, bean.getWoId());
				
				int affected = stmt.executeUpdate();
				if (affected == 1) {
					return true;
				} else {
					return false;
				}
				
			}
			catch(SQLException e) {
				System.err.println(e);
				return false;
			}

		}
		
		public static boolean complete(workOrder bean) throws Exception {
			int woid = bean.getWoId();
			int quant = bean.getQuantity();
			
			//By completing a work order, the quantity of the item of the work order is completed during production and is added to inventory.
			//first statement creates new inventory record of the completed item.
			String sqlInv = 
					"INSERT into inventory (itemId, quantity, lotId, batchId, manufacturerCode, comment) "
			+ "VALUES (" + bean.getItemId() + ", " + bean.getQuantity() + ", " + woid + ", NULL, NULL, NULL)";
			

			try (
					PreparedStatement stmtInv = conn.prepareStatement(sqlInv);
					) {
				int aff = stmtInv.executeUpdate();
				if(aff != 1) {// if statement executed continue, if not return false.
					return false;
				}
			}
			
			String sql =
					"UPDATE workOrder SET " +
					"complete = NOT complete " +
					"WHERE woId = ?";
			try (
					PreparedStatement stmt = conn.prepareStatement(sql);
					){
				
				stmt.setInt(1, woid);
				
				int affected = stmt.executeUpdate();
				if (affected == 1) {
					return true;
				} else {
					return false;
				}
				
			}
			catch(SQLException e) {
				System.err.println(e);
				return false;
			}

		}
		
		public static boolean close(workOrder bean) throws Exception {

			String sql =
					"UPDATE workOrder SET " +
					"close = NOT close " +
					"WHERE woId = ?";
			try (
					PreparedStatement stmt = conn.prepareStatement(sql);
					){
				
				stmt.setInt(1, bean.getWoId());
				
				int affected = stmt.executeUpdate();
				if (affected == 1) {
					return true;
				} else {
					return false;
				}
				
			}
			catch(SQLException e) {
				System.err.println(e);
				return false;
			}

		}
		
		public static void main(String[] args) throws Exception {
			
			System.out.println("Starting application");
			
			ConnectionManager.getInstance();
			
			displayAllRows();
			
			System.out.println("Functions: 1. Search Work Order, 2. Create new Work Order, 3. Update Work Order, 4. Complete Work Order to inventory, 5. Close Work Order, 0. Exit");
			int fun = InputManager.getIntegerInput("Enter corresponding integer: ");
			switch (fun) {
			case 1:
				int id = InputManager.getIntegerInput("Enter the item number for search: ");
				workOrder srch = getRow(id);
				if (srch != null) {
					System.out.println("Item ID: " + srch.getItemId());
					System.out.println("Quantity: " + srch.getQuantity());
					System.out.println("Due Date: " + srch.getSoId());
					System.out.println("Ship Date: " + srch.isComplete());
					System.out.println("Closure: " + srch.isClose());
				} else {
					System.out.println("Sales Order not found.");
				}
				break;

			case 2:
				workOrder create = new workOrder();
				create.setItemId(InputManager.getIntegerInput("Insert Item ID of Work Order: "));
				create.setQuantity(InputManager.getIntegerInput("Insert quantity of Item in Work Order: "));
				create.setSoId(InputManager.getIntegerInput("Insert ID of Sales Order for Work Order: "));
				
				if (insert(create)) {
					System.out.println("Operation successful.");
				} else {
					System.out.println("Operation unsuccessful.");
				}
				break;
				
			case 3:
				workOrder upd = getRow(InputManager.getIntegerInput("Enter Work Order ID to update: "));
				upd.setItemId(InputManager.getIntegerInput("Update Item ID: "));
				upd.setQuantity(InputManager.getIntegerInput("Update quantity: "));
				
				if(update(upd)) {
					System.out.println("Update successful.");
				} else {
					System.out.println("Update unsuccessful.");
				}
				break;
				
			case 4:
				workOrder cmp = getRow(InputManager.getIntegerInput("Enter Work Order ID to ship: "));
				
				if(complete(cmp)) {
					System.out.println("Update successful.");
				} else {
					System.out.println("Update unsuccessful.");
				}
				break;
				
			case 5:
				workOrder cls = new workOrder();
				cls.setSoId(InputManager.getIntegerInput("Enter Work Order ID to close: "));
				
				if(close(cls)) {
					System.out.println("Update successful.");
				} else {
					System.out.println("Update unsuccessful.");
				}
				break;
				
			case 0:
				break;
				
			default:
				break;
			}
			ConnectionManager.getInstance().close();
		}
}
