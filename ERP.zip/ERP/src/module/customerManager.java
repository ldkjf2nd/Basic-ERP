package module;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import beans.customer;
import db.ConnectionManager;
import db.InputManager;

public class customerManager {
	
	private static Connection conn = ConnectionManager.getInstance().getConnection();

	public static void displayAllRows() throws SQLException {
		String sql = "SELECT * FROM customer";
		try (

				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql);
				){

			System.out.println("Customer:");
			while (rs.next()) {
				StringBuffer bf = new StringBuffer();
				bf.append(rs.getString("customerId") +", ");
				bf.append(rs.getString("phone") +", ");
				bf.append(rs.getString("postalCode"));
				System.out.println(bf.toString());
			}
		}
	}
	
	public static customer getRow(String customerId) throws SQLException {

		String sql = "SELECT * FROM customer WHERE customerId = ?";
		ResultSet rs = null;

		try (
				PreparedStatement stmt = conn.prepareStatement(sql);
				){
			stmt.setString(1, customerId);
			rs = stmt.executeQuery();

			if (rs.next()) {
				customer bean = new customer();
				bean.setCustomer(customerId);
				bean.setPhone(rs.getString("phone"));
				bean.setPostalCode(rs.getString("postalCode"));
				return bean;
			} else {
				return null;
			}

		} catch (SQLException e) {
			System.err.println(e);
			return null;
		} finally {
			if (rs != null) {
				rs.close();
			}
		}

	}
	
	public static boolean insert(customer bean) throws Exception {

		String sql = "INSERT into customer (customerId, phone, postalCode) " +
				"VALUES (?, ?, ?)";
		ResultSet keys = null;
		try (
				PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				) {
			

			stmt.setString(1, bean.getCustomer());
			stmt.setString(2, bean.getPhone());
			stmt.setString(3, bean.getPostalCode());
			int affected = stmt.executeUpdate();
			
			if (affected != 1) {
				System.err.println("No rows affected");
				return false;
			}
			
		} catch (SQLException e) {
			System.err.println(e);
			return false;
		}
		return true;
	}
	
	public static boolean update(customer bean) throws Exception {

		String sql =
				"UPDATE customer SET " +
				"phone = ?, postalCode = ?" +
				"WHERE customerId = ?";
		try (
				PreparedStatement stmt = conn.prepareStatement(sql);
				){
			
			stmt.setString(1, bean.getPhone());
			stmt.setString(2, bean.getPostalCode());
			stmt.setString(3, bean.getCustomer());
			
			int affected = stmt.executeUpdate();
			if (affected == 1) {
				return true;
			} else {
				return false;
			}
			
		}
		catch(SQLException e) {
			System.err.println(e);
			return false;
		}

	}
	
	public static void main(String[] args) throws Exception {
		
		System.out.println("Starting application");
		
		ConnectionManager.getInstance();
		
		displayAllRows();
		
		System.out.println("Functions: 1. Search customer, 2. Insert customer, 3. Update customer, 0. Exit");
		
		int fun = InputManager.getIntegerInput("Enter corresponding integer: ");
		
		switch (fun) {
		case 1:
			String customerName = InputManager.getInput("Enter customer name: ");
			customer row = getRow(customerName);
			if (row != null) {
				System.out.println("Phone: " + row.getPhone());
				System.out.println("Postal: " + row.getPostalCode());
			} else {
				System.err.println("Row not found.");
			}
			break;

		case 2:
			customer newRow = new customer();
			newRow.setCustomer(InputManager.getInput("Enter new customer name: "));
			newRow.setPhone(InputManager.getInput("Enter new customer phone: "));
			newRow.setPostalCode(InputManager.getInput("Enter new customer postal code: "));
			
			boolean in = insert(newRow);
			if(in) {
				System.out.println("Insert new customer successful.");
			}
			break;
			
		case 3:
			String customerId = InputManager.getInput("Enter customer to be updated: ");
			customer up = getRow(customerId);
			if(up != null) {				

				up.setPhone(InputManager.getInput("Update customer phone: "));
				up.setPostalCode(InputManager.getInput("Update postal code: "));

				boolean res = update(up);
				if(res) {
					System.out.println("Update successful.");
				} else {
					System.out.println("Update unsuccessful.");
				}
			} else {
				System.err.println("Customer not found");
			}
			break;
			
		case 0:
			break;

			
		default:
			System.out.println("Invalid input");
			break;
		}
		
		ConnectionManager.getInstance().close();
	}
}
