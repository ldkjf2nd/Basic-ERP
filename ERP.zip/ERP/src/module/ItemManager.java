package module;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import beans.Item;
import db.ConnectionManager;
import db.InputManager;

public class ItemManager {

	private static Connection conn = ConnectionManager.getInstance().getConnection();
	
	public static void displayAllRows() throws SQLException {
		String sql = "SELECT item, partId, partName, description, revision, customerId FROM item";
		try (

				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql);
				){

			System.out.println("Item:");
			while (rs.next()) {
				StringBuffer bf = new StringBuffer();
				bf.append(rs.getInt("Item") + ": ");
				bf.append(rs.getString("partId") +", ");
				bf.append(rs.getString("partName") +", ");
				bf.append(rs.getString("description") +", ");
				bf.append(rs.getString("revision") +", ");
				bf.append(rs.getString("customerId"));
				System.out.println(bf.toString());
			}
		}
	}
	
	public static Item getRow(int itemId) throws SQLException {

		String sql = "SELECT * FROM item WHERE itemId = ?";
		ResultSet rs = null;

		try (
				PreparedStatement stmt = conn.prepareStatement(sql);
				){
			stmt.setInt(1, itemId);
			rs = stmt.executeQuery();

			if (rs.next()) {
				Item bean = new Item();
				bean.setItemId(itemId);
				bean.setPartId(rs.getString("partId"));
				bean.setPartName(rs.getString("partName"));
				bean.setDescription(rs.getString("description"));
				bean.setRevision(rs.getString("revision"));
				bean.setCustomerId(rs.getInt("customerId"));
				return bean;
			} else {
				return null;
			}

		} catch (SQLException e) {
			System.err.println(e);
			return null;
		} finally {
			if (rs != null) {
				rs.close();
			}
		}

	}
	
	public static boolean insert(Item bean) throws Exception {

		String sql = "INSERT into item (partId, partName, description, revision, customerId) " +
				"VALUES (?, ?, ?, ?, ?)";
		ResultSet keys = null;
		try (
				PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
				) {
			
			stmt.setString(1, bean.getPartId());
			stmt.setString(2, bean.getPartName());
			stmt.setString(3, bean.getDescription());
			stmt.setString(4, bean.getRevision());
			stmt.setInt(5, bean.getCustomerId());
			int affected = stmt.executeUpdate();
			
			if (affected == 1) {
				keys = stmt.getGeneratedKeys();
				keys.next();
				int newKey = keys.getInt(1);
				bean.setItemId(newKey);
			} else {
				System.err.println("No rows affected");
				return false;
			}
			
		} catch (SQLException e) {
			System.err.println(e);
			return false;
		} finally{
			if (keys != null) keys.close();
		}
		return true;
	}
	
	public static boolean update(Item bean) throws Exception {

		String sql =
				"UPDATE item SET " +
				"partId = ?, partName = ?, description = ?, revision = ?, customerId = ? " +
				"WHERE itemId = ?";
		try (
				PreparedStatement stmt = conn.prepareStatement(sql);
				){
			
			stmt.setString(1, bean.getPartId());
			stmt.setString(2, bean.getPartName());
			stmt.setString(3, bean.getDescription());
			stmt.setString(4, bean.getRevision());
			stmt.setInt(5, bean.getCustomerId());
			stmt.setInt(6, bean.getItemId());
			
			int affected = stmt.executeUpdate();
			if (affected == 1) {
				return true;
			} else {
				return false;
			}
			
		}
		catch(SQLException e) {
			System.err.println(e);
			return false;
		}

	}
	
	public static void main(String[] args) throws Exception {
		
		System.out.println("Starting application");
		
		ConnectionManager.getInstance();
		
		displayAllRows();
		
		System.out.println("Functions: 1. Search item, 2. Insert item, 3. Update item, 0. Exit");
		
		int fun = InputManager.getIntegerInput("Enter corresponding integer: ");
		
		switch (fun) {
		case 1:
			int id = InputManager.getIntegerInput("Enter the item number for search: ");
			Item srch = getRow(id);
			if (srch != null) {
				System.out.println("Part ID: " + srch.getPartId());
				System.out.println("Part Name: " + srch.getPartName());
				System.out.println("Description: " + srch.getDescription());
				System.out.println("Revision: " + srch.getRevision());
				System.out.println("Customer ID: " + srch.getCustomerId());
			} else {
				System.out.println("Item not found.");
			}
			break;

		case 2:
			Item insrt = new Item();
			insrt.setPartId(InputManager.getInput("Enter new item Part ID: "));
			insrt.setPartName(InputManager.getInput("Enter new item Part Name : "));
			insrt.setDescription(InputManager.getInput("Enter new item description : "));
			insrt.setRevision(InputManager.getInput("Enter new item Revision : "));
			insrt.setCustomerId(InputManager.getIntegerInput("Enter new item associated customer ID : "));
			
			if (insert(insrt)) {
				System.out.println("Insert successful.");
			} else {
				System.out.println("Insert unsuccessful.");
			}
			
			break;
			
		case 3:
			Item upd = getRow(InputManager.getIntegerInput("Enter ID of item to be updated: "));
			upd.setPartId(InputManager.getInput("Update item Part ID: "));
			upd.setPartName(InputManager.getInput("Update Part Name : "));
			upd.setDescription(InputManager.getInput("Update item description : "));
			upd.setRevision(InputManager.getInput("Update item Revision : "));
			upd.setCustomerId(InputManager.getIntegerInput("Update item associated customer ID : "));
			
			if (update(upd)) {
				System.out.println("Update successful.");
			} else {
				System.out.println("Update unsuccessful.");
			}
			
			break;
			
		case 0:
			break;
			
		default:
			break;
		}
	}

}
