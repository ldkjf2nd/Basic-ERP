package db;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class InputManager {
	
	public static String getInput(String input) {
		BufferedReader rdr = new BufferedReader(
				new InputStreamReader(System.in));

		System.out.print(input);
		System.out.flush();

		try {
			return rdr.readLine();
		} catch (Exception e) {
			return "Error: " + e.getMessage();
		}
	}


	public static int getIntegerInput(String input) throws NumberFormatException {
		String integer = getInput(input);
		return Integer.parseInt(integer);	
	}

}
